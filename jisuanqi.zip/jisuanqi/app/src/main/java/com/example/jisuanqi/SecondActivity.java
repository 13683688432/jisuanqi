package com.example.jisuanqi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.math.BigDecimal;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        EditText shuru = (EditText) findViewById(R.id.shuru);
        TextView shuchu = (TextView) findViewById(R.id.shuchu);
        Button changdu = (Button) findViewById(R.id.changdu);
        Button tiji = (Button) findViewById(R.id.tiji);
        Button erjinzhi = (Button) findViewById(R.id.erjinzhi);
        Button bajinzhi = (Button) findViewById(R.id.bajinzhi);
        Button shijinzhi = (Button) findViewById(R.id.shijinzhi);
        Button shiliujinzhi = (Button) findViewById(R.id.shiliujinzhi);
        Button sin = (Button) findViewById(R.id.sin);
        Button cos = (Button) findViewById(R.id.cos);
        Button tan = (Button) findViewById(R.id.tan);
        Button kaigenhao = (Button) findViewById(R.id.kaigenhao);
        Button qingkong = (Button) findViewById(R.id.qingkong);
        shuru.setText(getIntent().getStringExtra("num"));
        qingkong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                shuru.setText("");
            }
        });
        changdu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                if(shuru.getText().toString().equals("")){
                    shuchu.setText("请先输入数据 再进行转换");
                }
                else {
                    double[] m = {0};
                    m[0] = Double.parseDouble(shuru.getText().toString() + "");
                    shuchu.setText(m[0] + " 米 = " + (m[0] / 1000) + " 公里 = " + (m[0] * 100) + " 厘米 = " + (int) (m[0] * 1000000) + " 毫米");
                }
            }
        });
        tiji.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                if(shuru.getText().toString().equals("")){
                    shuchu.setText("请先输入数据 再进行转换");
                }
                else {
                    double[] m = {0};
                    m[0] = Double.parseDouble(shuru.getText().toString() + "");
                    shuchu.setText(m[0] + " 立方米 = " + (m[0] * 1000) + " 立方分米 = " + (int) (m[0] * 1000000) + " 立方厘米");
                }
            }
        });
        erjinzhi.setOnClickListener(new View.OnClickListener() {  //进制转化的方法我是选择将二进制8进制 十进制 十六进制等都先转化为二进制在进行计算其他进制
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                String m = shuru.getText().toString() + "";
                String K = "二进制：" + m + "   ";       //K是最后的输出
                int e = 0;   //e用来标记输入的数据是否规范   e为1时不规范
                for (int i = 0; i < m.length(); i++) {
                    if ((m.charAt(i) != '1') && (m.charAt(i) != '0') && (m.charAt(i) != '.')) {
                        e = 1;
                    }
                }
                if (e == 1) {
                    shuchu.setText("请输入正确的二进制码");
                }
                else if(shuru.getText().toString().equals("")){
                    shuchu.setText("请先输入数据 再进行转换");
                }
                else {
                    if (m.indexOf('.') != -1) {
                        int n = 0;
                        n = m.indexOf('.');   //n是小数点的位置  接下来想小数点两边添加0
                        //接下来是二进制转八进制
                        if ((m.length() - n) % 3 == 0) {         //小数点后面的小数部分  在末尾补零构成3位的整数倍
                            m = m + "0";
                        }
                        if ((m.length() - n) % 3 == 2) {
                            m = m + "00";
                        }
                        if (n % 3 == 1) {    //小数点前面的整数部分在第一位补零构成3位的整数倍
                            m = "00" + m;
                        }
                        if (n % 3 == 2) {
                            m = "0" + m;
                        }   //至此补零结束  开始计算八进制
                    } else {  //如果没有小数点
                        if (m.length() % 3 == 1) {
                            m = "00" + m;
                        }
                        if (m.length() % 3 == 2) {
                            m = "0" + m;
                        }
                    }
                    String O = "";      //O用来记录一下计算结果  O P Q分别代表八进制 十进制 十六进制
                    for (int i = 0; i < (m.length() / 3); i++) {
                        if (m.charAt(3 * i) == '.') {   //如果找到了小数点  就放入小数点

                            O = O + ".";
                            m = m.replace(".", "");

                        }
                        O = O + ((Integer.parseInt(m.charAt(3 * i) + "") * 4) + (Integer.parseInt(m.charAt(3 * i + 1) + "") * 2) + (Integer.parseInt(m.charAt(3 * i + 2) + "")));

                    }
                    K = K + "八进制:" + O + "   ";

                    //接下来是二进制转十进制
                    m = shuru.getText().toString() + "";
                    double P = 0;
                    if (m.indexOf('.') != -1) {   //如果有小数点
                        int k = m.indexOf('.');
                        m = m.replace(".", "");
                        for (int i = 0; i < m.length(); i++) {
                            P = P + (Integer.parseInt(m.charAt(i) + "")) * Math.pow(2, k - i - 1);
                        }
                    } else {
                        for (int i = 0; i < m.length(); i++) {
                            P = P + (Integer.parseInt(m.charAt(i) + "")) * Math.pow(2, m.length() - i - 1);
                        }
                    }
                    K = K + "十进制:" + P + "   ";

                    //接下来是二进制转十六进制
                    m = shuru.getText().toString() + "";
                    if (m.indexOf('.') != -1) {
                        int n = m.indexOf('.');   //n是小数点的位置  接下来想小数点两边添加0
                        //接下来是二进制转十六进制补零
                        if ((m.length() - n) % 4 == 0) {         //小数点后面的小数部分  在末尾补零构成4位的整数倍
                            m = m + "0";
                        }
                        if ((m.length() - n) % 4 == 3) {
                            m = m + "00";
                        }
                        if ((m.length() - n) % 4 == 2) {
                            m = m + "000";
                        }
                        if (n % 4 == 3) {    //小数点前面的整数部分在第一位补零构成4位的整数倍
                            m = "0" + m;
                        }
                        if (n % 4 == 2) {
                            m = "00" + m;
                        }
                        if (n % 4 == 1) {
                            m = "000" + m;
                        }
                        //至此补零结束  开始计算八进制
                    } else {  //如果没有小数点
                        if (m.length() % 4 == 1) {
                            m = "000" + m;
                        }
                        if (m.length() % 4 == 2) {
                            m = "00" + m;
                        }
                        if (m.length() % 4 == 3) {
                            m = "0" + m;
                        }
                    }
                    String Q = "";      //Q用来记录一下计算结果  O P Q分别代表八进制 十进制 十六进制
                    for (int i = 0; i < (m.length() / 4); i++) {
                        if (m.charAt(4 * i) == '.') {   //如果找到了小数点  就放入小数点
                            Q = Q + ".";
                            m = m.replace(".", "");
                        }
                        int k = ((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + "")));
                        //令k等于其十六进制的数字值  然后判断是否需要用ABCDEF来代替
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 10) {
                            Q = Q + "A";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 11) {
                            Q = Q + "B";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 12) {
                            Q = Q + "C";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 13) {
                            Q = Q + "D";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 14) {
                            Q = Q + "E";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 15) {
                            Q = Q + "F";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) < 10) {
                            Q = Q + k;
                        }
                    }
                    K = K + "十六进制:" + Q + "   ";
                    shuchu.setText(K);
                }
            }
        }); //到此是二进制转化八进制 十进制 十六进制的代码结束  其他进制都先转化为二进制


        //接下来是八进制转其他进制！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
        bajinzhi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                String m = shuru.getText().toString() + "";
                String G = shuru.getText().toString() + "";   //G是不变的   我这里是把输入直接变成二进制  然后直接运行二进制转换代码 最后吧输入改回去
                String h = "";     //h是二进制值
                int e = 0;   //e用来标记输入的数据是否规范   e为1时不规范
                for (int i = 0; i < m.length(); i++) {
                    if ((m.charAt(i) != '0') && (m.charAt(i) != '1') && (m.charAt(i) != '.')&& (m.charAt(i) != '2')&& (m.charAt(i) != '3')&& (m.charAt(i) != '4')&& (m.charAt(i) != '5')&& (m.charAt(i) != '6')&& (m.charAt(i) != '7')) {
                        e = 1;
                    }
                }
                if (e == 1) {
                    shuchu.setText("请输入正确的八进制码:0-7或者 “ . ”");
                }
                else if(shuru.getText().toString().equals("")){
                    shuchu.setText("请先输入数据 再进行转换");
                }
                else {
                    for (int i = 0; i < m.length(); i++) {
                        if (m.charAt(i) == '0') {
                            h = h + "000";
                        }
                        if (m.charAt(i) == '1') {
                            h = h + "001";
                        }
                        if (m.charAt(i) == '2') {
                            h = h + "010";
                        }
                        if (m.charAt(i) == '3') {
                            h = h + "011";
                        }
                        if (m.charAt(i) == '4') {
                            h = h + "100";
                        }
                        if (m.charAt(i) == '5') {
                            h = h + "101";
                        }
                        if (m.charAt(i) == '6') {
                            h = h + "110";
                        }
                        if (m.charAt(i) == '7') {
                            h = h + "111";
                        }
                        if (m.charAt(i) == '.') {
                            h = h + ".";
                        }
                    }
                    m = h;  //将二进制值放入m   接下来的代码就可以直接复制粘贴了
                    //八进制转化二进制结束  接下来的代码是复制的二进制转化其他进制的代码
                    shuru.setText(m + "");

                    String K = "二进制：" + m + "   ";       //K是最后的输出
                    if (m.indexOf('.') != -1) {
                        int n = 0;
                        n = m.indexOf('.');   //n是小数点的位置  接下来想小数点两边添加0
                        //接下来是二进制转八进制
                        if ((m.length() - n) % 3 == 0) {         //小数点后面的小数部分  在末尾补零构成3位的整数倍
                            m = m + "0";
                        }
                        if ((m.length() - n) % 3 == 2) {
                            m = m + "00";
                        }
                        if (n % 3 == 1) {    //小数点前面的整数部分在第一位补零构成3位的整数倍
                            m = "00" + m;
                        }
                        if (n % 3 == 2) {
                            m = "0" + m;
                        }   //至此补零结束  开始计算八进制
                    } else {  //如果没有小数点
                        if (m.length() % 3 == 1) {
                            m = "00" + m;
                        }
                        if (m.length() % 3 == 2) {
                            m = "0" + m;
                        }
                    }
                    String O = "";      //O用来记录一下计算结果  O P Q分别代表八进制 十进制 十六进制
                    for (int i = 0; i < (m.length() / 3); i++) {
                        if (m.charAt(3 * i) == '.') {   //如果找到了小数点  就放入小数点

                            O = O + ".";
                            m = m.replace(".", "");

                        }
                        O = O + ((Integer.parseInt(m.charAt(3 * i) + "") * 4) + (Integer.parseInt(m.charAt(3 * i + 1) + "") * 2) + (Integer.parseInt(m.charAt(3 * i + 2) + "")));

                    }
                    K = K + "八进制:" + O + "   ";

                    //接下来是二进制转十进制
                    m = shuru.getText().toString() + "";
                    double P = 0;
                    if (m.indexOf('.') != -1) {   //如果有小数点
                        int k = m.indexOf('.');
                        m = m.replace(".", "");
                        for (int i = 0; i < m.length(); i++) {
                            P = P + (Integer.parseInt(m.charAt(i) + "")) * Math.pow(2, k - i - 1);
                        }
                    } else {
                        for (int i = 0; i < m.length(); i++) {
                            P = P + (Integer.parseInt(m.charAt(i) + "")) * Math.pow(2, m.length() - i - 1);
                        }
                    }
                    K = K + "十进制:" + P + "   ";

                    //接下来是二进制转十六进制
                    m = shuru.getText().toString() + "";
                    if (m.indexOf('.') != -1) {
                        int n = m.indexOf('.');   //n是小数点的位置  接下来想小数点两边添加0
                        //接下来是二进制转十六进制补零
                        if ((m.length() - n) % 4 == 0) {         //小数点后面的小数部分  在末尾补零构成4位的整数倍
                            m = m + "0";
                        }
                        if ((m.length() - n) % 4 == 3) {
                            m = m + "00";
                        }
                        if ((m.length() - n) % 4 == 2) {
                            m = m + "000";
                        }
                        if (n % 4 == 3) {    //小数点前面的整数部分在第一位补零构成4位的整数倍
                            m = "0" + m;
                        }
                        if (n % 4 == 2) {
                            m = "00" + m;
                        }
                        if (n % 4 == 1) {
                            m = "000" + m;
                        }
                        //至此补零结束  开始计算八进制
                    } else {  //如果没有小数点
                        if (m.length() % 4 == 1) {
                            m = "000" + m;
                        }
                        if (m.length() % 4 == 2) {
                            m = "00" + m;
                        }
                        if (m.length() % 4 == 3) {
                            m = "0" + m;
                        }
                    }
                    String Q = "";      //Q用来记录一下计算结果  O P Q分别代表八进制 十进制 十六进制
                    for (int i = 0; i < (m.length() / 4); i++) {
                        if (m.charAt(4 * i) == '.') {   //如果找到了小数点  就放入小数点
                            Q = Q + ".";
                            m = m.replace(".", "");
                        }
                        int k = ((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + "")));
                        //令k等于其十六进制的数字值  然后判断是否需要用ABCDEF来代替
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 10) {
                            Q = Q + "A";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 11) {
                            Q = Q + "B";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 12) {
                            Q = Q + "C";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 13) {
                            Q = Q + "D";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 14) {
                            Q = Q + "E";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 15) {
                            Q = Q + "F";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) < 10) {
                            Q = Q + k;
                        }
                    }
                    K = K + "十六进制:" + Q + "   ";
                    shuru.setText(G);
                    shuchu.setText(K);
                }
            }
        });

        //接下来是十进制转化其他进制  方式和八进制一样  先转化为二进制再转化为其他进制!!!!!!!!!!!!!!!!
        shijinzhi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                String m = shuru.getText().toString() + "";
                String G = shuru.getText().toString() + "";   //G是不变的   我这里是把输入直接变成二进制  然后直接运行二进制转换代码 最后吧输入改回去
                String h = "";     //h是二进制值
                //将一切数据转化成二进制放入h即可
                int e = 0;   //e用来标记输入的数据是否规范   e为1时不规范
                for (int i = 0; i < m.length(); i++) {
                    if ((m.charAt(i) != '0') && (m.charAt(i) != '1') && (m.charAt(i) != '.') && (m.charAt(i) != '2') && (m.charAt(i) != '3') && (m.charAt(i) != '4') && (m.charAt(i) != '5') && (m.charAt(i) != '6') && (m.charAt(i) != '7')&& (m.charAt(i) != '8')&& (m.charAt(i) != '9')) {
                        e = 1;
                    }
                }
                if (e == 1) {
                    shuchu.setText("请输入正确的十进制码:0-9或者 “ . ”");
                }
                else if(shuru.getText().toString().equals("")){
                    shuchu.setText("请先输入数据 再进行转换");
                }
                else {
                    if (m.indexOf('.') != -1) {    //如果存在小数点
                        int j = (int) (Double.parseDouble(m));      //让J等于除二后的结果
                        while (true) {
                            if (j == 1) {
                                h = "1" + h;
                                break;
                            } else if (j == 2) {
                                h = "10" + h;
                                break;
                            } else if (j % 2 == 1) {
                                h = "1" + h;
                                j = j / 2;
                            } else if (j % 2 == 0) {
                                h = "0" + h;
                                j = j / 2;
                            }
                        }
                        h = h + ".";
                        double k = BigDecimal.valueOf(Double.parseDouble(m)).subtract(BigDecimal.valueOf((int) (Double.parseDouble(m)))).doubleValue();  //k是十进制数的小数部分   这里在网上查询并使用了BigDecimal方法
                        while (true) {
                            if (k * 2 == 1) {
                                h = h + "1";
                                break;
                            } else if (k * 2 > 1) {
                                h = h + "1";
                                k = k * 2 - 1;
                            } else if (k * 2 < 1) {
                                h = h + "0";
                                k = k * 2;
                            }
                        }
                    }
                    //接下来是没有小数点的情况  直接复制有小数点的整数部分的代码
                    else {
                        int j = (int) (Double.parseDouble(m));      //让J等于除二后的结果
                        while (true) {
                            if (j == 1) {
                                h = "1" + h;
                                break;
                            } else if (j == 2) {
                                h = "10" + h;
                                break;
                            } else if (j % 2 == 1) {
                                h = "1" + h;
                                j = j / 2;
                            } else if (j % 2 == 0) {
                                h = "0" + h;
                                j = j / 2;
                            }
                        }
                    }
                    m = h;  //将二进制值放入m   接下来的代码就可以直接复制粘贴了
                    //八进制转化二进制结束  接下来的代码是复制的二进制转化其他进制的代码
                    shuru.setText(m + "");

                    String K = "二进制：" + m + "   ";       //K是最后的输出
                    if (m.indexOf('.') != -1) {
                        int n = 0;
                        n = m.indexOf('.');   //n是小数点的位置  接下来想小数点两边添加0
                        //接下来是二进制转八进制
                        if ((m.length() - n) % 3 == 0) {         //小数点后面的小数部分  在末尾补零构成3位的整数倍
                            m = m + "0";
                        }
                        if ((m.length() - n) % 3 == 2) {
                            m = m + "00";
                        }
                        if (n % 3 == 1) {    //小数点前面的整数部分在第一位补零构成3位的整数倍
                            m = "00" + m;
                        }
                        if (n % 3 == 2) {
                            m = "0" + m;
                        }   //至此补零结束  开始计算八进制
                    } else {  //如果没有小数点
                        if (m.length() % 3 == 1) {
                            m = "00" + m;
                        }
                        if (m.length() % 3 == 2) {
                            m = "0" + m;
                        }
                    }
                    String O = "";      //O用来记录一下计算结果  O P Q分别代表八进制 十进制 十六进制
                    for (int i = 0; i < (m.length() / 3); i++) {
                        if (m.charAt(3 * i) == '.') {   //如果找到了小数点  就放入小数点

                            O = O + ".";
                            m = m.replace(".", "");

                        }
                        O = O + ((Integer.parseInt(m.charAt(3 * i) + "") * 4) + (Integer.parseInt(m.charAt(3 * i + 1) + "") * 2) + (Integer.parseInt(m.charAt(3 * i + 2) + "")));

                    }
                    K = K + "八进制:" + O + "   ";

                    //接下来是二进制转十进制
                    m = shuru.getText().toString() + "";
                    double P = 0;
                    if (m.indexOf('.') != -1) {   //如果有小数点
                        int k = m.indexOf('.');
                        m = m.replace(".", "");
                        for (int i = 0; i < m.length(); i++) {
                            P = P + (Integer.parseInt(m.charAt(i) + "")) * Math.pow(2, k - i - 1);
                        }
                    } else {
                        for (int i = 0; i < m.length(); i++) {
                            P = P + (Integer.parseInt(m.charAt(i) + "")) * Math.pow(2, m.length() - i - 1);
                        }
                    }
                    K = K + "十进制:" + P + "   ";

                    //接下来是二进制转十六进制
                    m = shuru.getText().toString() + "";
                    if (m.indexOf('.') != -1) {
                        int n = m.indexOf('.');   //n是小数点的位置  接下来想小数点两边添加0
                        //接下来是二进制转十六进制补零
                        if ((m.length() - n) % 4 == 0) {         //小数点后面的小数部分  在末尾补零构成4位的整数倍
                            m = m + "0";
                        }
                        if ((m.length() - n) % 4 == 3) {
                            m = m + "00";
                        }
                        if ((m.length() - n) % 4 == 2) {
                            m = m + "000";
                        }
                        if (n % 4 == 3) {    //小数点前面的整数部分在第一位补零构成4位的整数倍
                            m = "0" + m;
                        }
                        if (n % 4 == 2) {
                            m = "00" + m;
                        }
                        if (n % 4 == 1) {
                            m = "000" + m;
                        }
                        //至此补零结束  开始计算八进制
                    } else {  //如果没有小数点
                        if (m.length() % 4 == 1) {
                            m = "000" + m;
                        }
                        if (m.length() % 4 == 2) {
                            m = "00" + m;
                        }
                        if (m.length() % 4 == 3) {
                            m = "0" + m;
                        }
                    }
                    String Q = "";      //Q用来记录一下计算结果  O P Q分别代表八进制 十进制 十六进制
                    for (int i = 0; i < (m.length() / 4); i++) {
                        if (m.charAt(4 * i) == '.') {   //如果找到了小数点  就放入小数点
                            Q = Q + ".";
                            m = m.replace(".", "");
                        }
                        int k = ((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + "")));
                        //令k等于其十六进制的数字值  然后判断是否需要用ABCDEF来代替
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 10) {
                            Q = Q + "A";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 11) {
                            Q = Q + "B";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 12) {
                            Q = Q + "C";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 13) {
                            Q = Q + "D";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 14) {
                            Q = Q + "E";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 15) {
                            Q = Q + "F";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) < 10) {
                            Q = Q + k;
                        }
                    }
                    K = K + "十六进制:" + Q + "   ";
                    shuru.setText(G);
                    shuchu.setText(K);


                }
            }
        });

        //接下来是十六进制转化其他进制  方式和八进制一样 先转化为二进制再转化为其他进制
        shiliujinzhi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                String m = shuru.getText().toString() + "";
                String G = shuru.getText().toString() + "";   //G是不变的   我这里是把输入直接变成二进制  然后直接运行二进制转换代码 最后吧输入改回去
                String h = "";     //h是二进制值
                int e = 0;   //e用来标记输入的数据是否规范   e为1时不规范
                for (int i = 0; i < m.length(); i++) {
                    if ((m.charAt(i) != '0') && (m.charAt(i) != '1') && (m.charAt(i) != '.') && (m.charAt(i) != '2') && (m.charAt(i) != '3') && (m.charAt(i) != '4') && (m.charAt(i) != '5') && (m.charAt(i) != '6') && (m.charAt(i) != '7') && (m.charAt(i) != '8') && (m.charAt(i) != '9')&& (m.charAt(i) != 'A')&& (m.charAt(i) != 'B')&& (m.charAt(i) != 'C')&& (m.charAt(i) != 'D')&& (m.charAt(i) != 'E')&& (m.charAt(i) != 'F')) {
                        e = 1;
                    }
                }
                if (e == 1) {
                    shuchu.setText("请输入正确的十六进制码:0-F或者 “ . ”");
                }
                else if(shuru.getText().toString().equals("")){
                    shuchu.setText("请先输入数据 再进行转换");
                }
                else {
                    for (int i = 0; i < m.length(); i++) {
                        if (m.charAt(i) == '0') {
                            h = h + "0000";
                        }
                        if (m.charAt(i) == '1') {
                            h = h + "0001";
                        }
                        if (m.charAt(i) == '2') {
                            h = h + "0010";
                        }
                        if (m.charAt(i) == '3') {
                            h = h + "0011";
                        }
                        if (m.charAt(i) == '4') {
                            h = h + "0100";
                        }
                        if (m.charAt(i) == '5') {
                            h = h + "0101";
                        }
                        if (m.charAt(i) == '6') {
                            h = h + "0110";
                        }
                        if (m.charAt(i) == '7') {
                            h = h + "0111";
                        }
                        if (m.charAt(i) == '8') {
                            h = h + "1000";
                        }
                        if (m.charAt(i) == '9') {
                            h = h + "1001";
                        }
                        if (m.charAt(i) == 'A') {
                            h = h + "1010";
                        }
                        if (m.charAt(i) == 'B') {
                            h = h + "1011";
                        }
                        if (m.charAt(i) == 'C') {
                            h = h + "1100";
                        }
                        if (m.charAt(i) == 'D') {
                            h = h + "1101";
                        }
                        if (m.charAt(i) == 'E') {
                            h = h + "1110";
                        }
                        if (m.charAt(i) == 'F') {
                            h = h + "1111";
                        }
                        if (m.charAt(i) == '.') {
                            h = h + ".";
                        }
                    }
                    m = h;  //将二进制值放入m   接下来的代码就可以直接复制粘贴了
                    //八进制转化二进制结束  接下来的代码是复制的二进制转化其他进制的代码
                    shuru.setText(m + "");

                    String K = "二进制：" + m + "   ";       //K是最后的输出
                    if (m.indexOf('.') != -1) {
                        int n = 0;
                        n = m.indexOf('.');   //n是小数点的位置  接下来想小数点两边添加0
                        //接下来是二进制转八进制
                        if ((m.length() - n) % 3 == 0) {         //小数点后面的小数部分  在末尾补零构成3位的整数倍
                            m = m + "0";
                        }
                        if ((m.length() - n) % 3 == 2) {
                            m = m + "00";
                        }
                        if (n % 3 == 1) {    //小数点前面的整数部分在第一位补零构成3位的整数倍
                            m = "00" + m;
                        }
                        if (n % 3 == 2) {
                            m = "0" + m;
                        }   //至此补零结束  开始计算八进制
                    } else {  //如果没有小数点
                        if (m.length() % 3 == 1) {
                            m = "00" + m;
                        }
                        if (m.length() % 3 == 2) {
                            m = "0" + m;
                        }
                    }
                    String O = "";      //O用来记录一下计算结果  O P Q分别代表八进制 十进制 十六进制
                    for (int i = 0; i < (m.length() / 3); i++) {
                        if (m.charAt(3 * i) == '.') {   //如果找到了小数点  就放入小数点

                            O = O + ".";
                            m = m.replace(".", "");

                        }
                        O = O + ((Integer.parseInt(m.charAt(3 * i) + "") * 4) + (Integer.parseInt(m.charAt(3 * i + 1) + "") * 2) + (Integer.parseInt(m.charAt(3 * i + 2) + "")));

                    }
                    K = K + "八进制:" + O + "   ";

                    //接下来是二进制转十进制
                    m = shuru.getText().toString() + "";
                    double P = 0;
                    if (m.indexOf('.') != -1) {   //如果有小数点
                        int k = m.indexOf('.');
                        m = m.replace(".", "");
                        for (int i = 0; i < m.length(); i++) {
                            P = P + (Integer.parseInt(m.charAt(i) + "")) * Math.pow(2, k - i - 1);
                        }
                    } else {
                        for (int i = 0; i < m.length(); i++) {
                            P = P + (Integer.parseInt(m.charAt(i) + "")) * Math.pow(2, m.length() - i - 1);
                        }
                    }
                    K = K + "十进制:" + P + "   ";

                    //接下来是二进制转十六进制
                    m = shuru.getText().toString() + "";
                    if (m.indexOf('.') != -1) {
                        int n = m.indexOf('.');   //n是小数点的位置  接下来想小数点两边添加0
                        //接下来是二进制转十六进制补零
                        if ((m.length() - n) % 4 == 0) {         //小数点后面的小数部分  在末尾补零构成4位的整数倍
                            m = m + "0";
                        }
                        if ((m.length() - n) % 4 == 3) {
                            m = m + "00";
                        }
                        if ((m.length() - n) % 4 == 2) {
                            m = m + "000";
                        }
                        if (n % 4 == 3) {    //小数点前面的整数部分在第一位补零构成4位的整数倍
                            m = "0" + m;
                        }
                        if (n % 4 == 2) {
                            m = "00" + m;
                        }
                        if (n % 4 == 1) {
                            m = "000" + m;
                        }
                        //至此补零结束  开始计算八进制
                    } else {  //如果没有小数点
                        if (m.length() % 4 == 1) {
                            m = "000" + m;
                        }
                        if (m.length() % 4 == 2) {
                            m = "00" + m;
                        }
                        if (m.length() % 4 == 3) {
                            m = "0" + m;
                        }
                    }
                    String Q = "";      //Q用来记录一下计算结果  O P Q分别代表八进制 十进制 十六进制
                    for (int i = 0; i < (m.length() / 4); i++) {
                        if (m.charAt(4 * i) == '.') {   //如果找到了小数点  就放入小数点
                            Q = Q + ".";
                            m = m.replace(".", "");
                        }
                        int k = ((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + "")));
                        //令k等于其十六进制的数字值  然后判断是否需要用ABCDEF来代替
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 10) {
                            Q = Q + "A";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 11) {
                            Q = Q + "B";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 12) {
                            Q = Q + "C";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 13) {
                            Q = Q + "D";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 14) {
                            Q = Q + "E";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) == 15) {
                            Q = Q + "F";
                        }
                        if (((Integer.parseInt(m.charAt(4 * i) + "") * 8) + (Integer.parseInt(m.charAt(4 * i + 1) + "") * 4) + (Integer.parseInt(m.charAt(4 * i + 2) + "") * 2) + (Integer.parseInt(m.charAt(4 * i + 3) + ""))) < 10) {
                            Q = Q + k;
                        }
                    }
                    K = K + "十六进制:" + Q + "   ";
                    shuru.setText(G);
                    shuchu.setText(K);
                }
            }
        });

        //接下来是三角函数的sin运算
        sin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                if(shuru.getText().toString().equals("")){
                    shuchu.setText("请先输入数据 再进行转换");
                }
                else {
                    double m = Double.parseDouble(shuru.getText().toString());      //直接利用java语言自带的函数
                    shuchu.setText("Sin" + m + " = " + Math.sin(m));
                }
            }
        });
        cos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                if(shuru.getText().toString().equals("")){
                    shuchu.setText("请先输入数据 再进行转换");
                }
                else {
                    double m = Double.parseDouble(shuru.getText().toString());      //直接利用java语言自带的函数
                    shuchu.setText("Cos" + m + " = " + Math.cos(m));
                }
            }
        });
        tan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                if(shuru.getText().toString().equals("")){
                    shuchu.setText("请先输入数据 再进行转换");
                }
                else {
                    double m = Double.parseDouble(shuru.getText().toString());      //直接利用java语言自带的函数
                    shuchu.setText("Tan" + m + " = " + Math.tan(m));
                }
            }
        });
        kaigenhao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuru = (EditText) findViewById(R.id.shuru);
                TextView shuchu = (TextView) findViewById(R.id.shuchu);
                if(shuru.getText().toString().equals("")){
                    shuchu.setText("请先输入数据 再进行转换");
                }
                else if(Double.parseDouble(shuru.getText().toString())<0)
                {
                    shuchu.setText("根号内的数不可以小于0");
                }
                else {
                    double m = Double.parseDouble(shuru.getText().toString());      //直接利用java语言自带的函数
                    shuchu.setText(m + "开根号结果为" + " : " + Math.sqrt(m));
                }
            }
        });
















    }












        public void startMainActivity (View view){
            Intent intent = new Intent();
            intent.setClass(this, MainActivity.class);
            //启动
            startActivity(intent);
        }
}