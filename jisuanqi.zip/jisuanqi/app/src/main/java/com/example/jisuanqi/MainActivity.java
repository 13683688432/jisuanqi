package com.example.jisuanqi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.math.BigDecimal;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //下面是数字以及加减乘除百分比 点 清零 左右括号
        final int[] b = {1};
        final int[] kuohao = {0};   //括号为0时  说明没有左括号  为1时出现左括号  放入右括号以后再变成0
        Button yi = (Button)findViewById(R.id.yi);
        yi.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(b[0] ==1){    //第一位数字需要清空屏幕
                    ed1.setText("1");
                    b[0] =0;
                }
                else {
                    String S = ed1.getText().toString() + "1";
                    ed1.setText(S);
                }
            }
        });
        Button er = (Button)findViewById(R.id.er);
        er.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(b[0] ==1){    //第一位数字需要清空屏幕
                    ed1.setText("2");
                    b[0] =0;
                }
                else {
                    String S = ed1.getText().toString() + "2";
                    ed1.setText(S);
                }
            }
        });
        Button san = (Button)findViewById(R.id.san);
        san.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(b[0] ==1){    //第一位数字需要清空屏幕
                    ed1.setText("3");
                    b[0] =0;
                }
                else {
                    String S = ed1.getText().toString() + "3";
                    ed1.setText(S);
                }
            }
        });
        Button si = (Button)findViewById(R.id.si);
        si.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(b[0] ==1){    //第一位数字需要清空屏幕
                    ed1.setText("4");
                    b[0] =0;
                }
                else {
                    String S = ed1.getText().toString() + "4";
                    ed1.setText(S);
                }
            }
        });
        Button wu = (Button)findViewById(R.id.wu);
        wu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(b[0] ==1){    //第一位数字需要清空屏幕
                    ed1.setText("5");
                    b[0] =0;
                }
                else {
                    String S = ed1.getText().toString() + "5";
                    ed1.setText(S);
                }
            }
        });
        Button liu = (Button)findViewById(R.id.liu);
        liu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(b[0] ==1){    //第一位数字需要清空屏幕
                    ed1.setText("6");
                    b[0] =0;
                }
                else {
                    String S = ed1.getText().toString() + "6";
                    ed1.setText(S);
                }
            }
        });
        Button qi = (Button)findViewById(R.id.qi);
        qi.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(b[0] ==1){    //第一位数字需要清空屏幕
                    ed1.setText("7");
                    b[0] =0;
                }
                else {
                    String S = ed1.getText().toString() + "7";
                    ed1.setText(S);
                }
            }
        });
        Button ba = (Button)findViewById(R.id.ba);
        ba.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(b[0] ==1){    //第一位数字需要清空屏幕
                    ed1.setText("8");
                    b[0] =0;
                }
                else {
                    String S = ed1.getText().toString() + "8";
                    ed1.setText(S);
                }
            }
        });
        Button jiu = (Button)findViewById(R.id.jiu);
        jiu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(b[0] ==1){    //第一位数字需要清空屏幕
                    ed1.setText("9");
                    b[0] =0;
                }
                else {
                    String S = ed1.getText().toString() + "9";
                    ed1.setText(S);
                }
            }
        });
        Button ling = (Button)findViewById(R.id.ling);
        ling.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(b[0] ==1){    //第一位数字需要清空屏幕
                    ed1.setText("0");
                    b[0] =0;
                }
                else {
                    String S = ed1.getText().toString() + "0";
                    ed1.setText(S);
                }
            }
        });
        Button dian = (Button)findViewById(R.id.dian);
        dian.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(ed1.getText().toString().indexOf('.')!=-1){
                    TextView tx = (TextView)findViewById(R.id.tx) ;
                    tx.setText("不能同时有两个小数点");
                }
                else if((ed1.getText().toString().charAt(0)=='+')||(ed1.getText().toString().charAt(0)=='-')||(ed1.getText().toString().charAt(0)=='X')||(ed1.getText().toString().charAt(0)=='÷')){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("输入不规范:请不要在运算符后输入小数点");
                }
                else if((ed1.getText().toString().charAt(0)=='(')||(ed1.getText().toString().charAt(0)==')')){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("输入不规范:请不要在括号后面输入小数点");
                }
                else if((ed1.getText().toString()).equals(" ")){       //判断是否为空  如果是空的的话不能输入小数点
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("不可以直接输入小数点");
                }
                else{
                    String S = ed1.getText().toString()+".";
                    ed1.setText(S);
                }
            }
        });
        //数字和点只需要再原有基础上增加数  小数点不能同时存在两个
        final double M[] = new double[10];   //因为运算中总是数字-运算符-数字-运算符的关系  所以设置M和N数组分别存放数和运算符
        final char N[] = new char[10];           //这里我只设置了10位  也就是说最多可以同时存放10个数和10个运算符   这个根据需要可以更改
        final int[] a = {0};        //a代表数字在数组中存放的位置
        final int [] c = {0};      //c代表运算符所在位置

        final Button[] jia = {(Button) findViewById(R.id.jia)};
        jia[0].setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(ed1.getText().toString().charAt(0)==')')
                {
                    N[c[0]]='+';
                    ed1.setText("+");
                    a[0]++;
                    c[0]++;
                    b[0]=1;
                }
                else if(((ed1.getText().toString().charAt(0)=='(')||(ed1.getText().toString().charAt(0)=='+')||(ed1.getText().toString().charAt(0)=='-')||(ed1.getText().toString().charAt(0)=='X')||(ed1.getText().toString().charAt(0)=='÷'))&&ed1.getText().toString().length()==1){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("输入不规范:请不要重复输入运算符");
                }
                else if((ed1.getText().toString()).equals(" ")){       //判断是否为空  如果是空的的话不能输入小数点
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("不可以直接输入加号");
                }
                else {
                    M[a[0]] = Double.parseDouble(ed1.getText().toString() + "");
                    ed1.setText("+");
                    N[c[0]] = '+';
                    a[0]++;
                    c[0]++;
                    b[0] = 1;    //b设为1  下一次输入需要清空屏幕
                }
            }
        });
        Button jian = (Button)findViewById(R.id.jian);
        jian.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if(ed1.getText().toString().charAt(0)==')')
                {
                    N[c[0]]=')';
                    ed1.setText("-");
                    a[0]++;
                    c[0]++;
                    b[0]=1;
                }
                else if(((ed1.getText().toString().charAt(0)=='(')||(ed1.getText().toString().charAt(0)=='+')||(ed1.getText().toString().charAt(0)=='-')||(ed1.getText().toString().charAt(0)=='X')||(ed1.getText().toString().charAt(0)=='÷'))&&ed1.getText().toString().length()==1){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("输入不规范:请不要重复输入运算符");
                }
                else if((ed1.getText().toString()).equals(" ")){       //判断是否为空  如果是空的的话不能输入小数点
                    TextView tx = (TextView)findViewById(R.id.tx);
                    ed1.setText("-");
                    b[0]=0;      //这里需要注意的是  当开头为减号时  这个数字代表负数  那么接下来的数字输入是不需要清空的
                }
                else {
                M[a[0]] = Double.parseDouble(ed1.getText().toString()+"");
                ed1.setText("-");
                N[c[0]] = '-';
                a[0]++;
                c[0]++;
                b[0]=1;    //b设为1  下一次输入需要清空屏幕
            }
            }
        });
        Button cheng = (Button)findViewById(R.id.cheng);
        cheng.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                TextView ed1 = (TextView) findViewById(R.id.ed1);
                if (ed1.getText().toString().charAt(0) == ')') {
                    N[c[0]] = 'X';
                    ed1.setText("X");
                    a[0]++;
                    c[0]++;
                    b[0] = 1;
                }
                else if(((ed1.getText().toString().charAt(0)=='(')||(ed1.getText().toString().charAt(0)=='+')||(ed1.getText().toString().charAt(0)=='-')||(ed1.getText().toString().charAt(0)=='X')||(ed1.getText().toString().charAt(0)=='÷'))&&ed1.getText().toString().length()==1){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("输入不规范:请不要重复输入运算符");
                }
                else if((ed1.getText().toString()).equals(" ")){       //判断是否为空  如果是空的的话不能输入乘号
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("不可以直接输入乘号");
                }
                else {
                    M[a[0]] = Double.parseDouble(ed1.getText().toString() + "");
                    ed1.setText("X");
                    N[c[0]] = 'X';
                    a[0]++;
                    c[0]++;
                    b[0] = 1;    //b设为1  下一次输入需要清空屏幕
                }
            }
        });
        Button chu = (Button)findViewById(R.id.chu);
        chu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                TextView ed1 = (TextView) findViewById(R.id.ed1);
                if (ed1.getText().toString().charAt(0) == ')') {
                    N[c[0]] = '÷';
                    ed1.setText("÷");
                    a[0]++;
                    c[0]++;
                    b[0] = 1;
                }
                else if(((ed1.getText().toString().charAt(0)=='(')||(ed1.getText().toString().charAt(0)=='+')||(ed1.getText().toString().charAt(0)=='-')||(ed1.getText().toString().charAt(0)=='X')||(ed1.getText().toString().charAt(0)=='÷'))&&ed1.getText().toString().length()==1){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("输入不规范:请不要重复输入运算符");
                }
                else if((ed1.getText().toString()).equals(" ")){       //判断是否为空  如果是空的的话不能输入小数点
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("不可以直接输入除号");
                }
                else {
                    M[a[0]] = Double.parseDouble(ed1.getText().toString() + "");
                    ed1.setText("÷");
                    N[c[0]] = '÷';
                    a[0]++;
                    c[0]++;
                    b[0] = 1;    //b设为1  下一次输入需要清空屏幕
                }
            }
        });
        Button tuige = (Button)findViewById(R.id.tuige);
        tuige.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if((ed1.getText().toString()).equals(" ")){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("别退格了  啥都没有了");
                }
                else if((ed1.getText().toString()).isEmpty()){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("别退格了  啥都没有了");
                }
                else {
                    ed1.setText(ed1.getText().toString().substring(0, ed1.getText().toString().length() - 1));
                }
            }
        });

        Button zuo = (Button)findViewById(R.id.zuo);
        zuo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                if((ed1.getText().toString().charAt(0)=='(')||(ed1.getText().toString().charAt(0)==')')){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("输入不规范：已经存在括号");
                }
                else if(isNumeric(ed1.getText()+"")){     //左括号前面不可以是数字
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("输入不规范：数字后面需要运算符");
                }
                else if(kuohao[0]==1){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("已经存在左括号");
                }
                else{
                ed1.setText("(");
                N[c[0]] = '(';      //左括号前面一定是运算符  所以不用存入数
                a[0]++;
                c[0]++;
                b[0]=1;
                kuohao[0] =1;   //括号为1代表 出现了左括号  接下来等待右括号
                }
            }
        });
        Button you = (Button)findViewById(R.id.you);
        you.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                TextView ed1 = (TextView) findViewById(R.id.ed1);
                if ((ed1.getText().toString().charAt(0) == '+') || (ed1.getText().toString().charAt(0) == '-')|| (ed1.getText().toString().charAt(0) == 'X')|| (ed1.getText().toString().charAt(0) == '÷')) {
                    TextView tx = (TextView) findViewById(R.id.tx);
                    tx.setText("输入不规范：运算符后面不可以添加括号");
                }
                else if((ed1.getText().toString().charAt(0) == '(')){
                    TextView tx = (TextView) findViewById(R.id.tx);
                    tx.setText("括号内需要内容！");
                }
                else if(kuohao[0] ==0){
                    TextView tx = (TextView) findViewById(R.id.tx);
                    tx.setText("前面没有左括号,不可以添加右括号");
                }
                else {
                    M[a[0]] = Double.parseDouble(ed1.getText().toString());
                    ed1.setText(")");
                    N[c[0]] = ')';
                    a[0]++;
                    c[0]++;
                    kuohao[0]=0;
                }
            }
        });
        Button CE = (Button)findViewById(R.id.CE);
        CE.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                ed1.setText(" ");
                for(int i=0;i<10;i++) {
                    M[i] = -1;   //数组-1代表无
                    N[i] = 0;       //运算符0代表无
                }
                a[0]=0;
                c[0]=0;
                b[0]=1;   //此时的b需要为1  因为空格也是一种字符
                kuohao[0]=0;   //括号的标记也清零
            }
        });
        Button bangzhu = (Button)findViewById(R.id.bangzhu);    //显示帮助
        bangzhu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView tx = (TextView)findViewById(R.id.tx) ;
                TextView ed1 = (TextView)findViewById(R.id.ed1) ;
                tx.setText("这是帮助");
            }
        });

        //接下来是计算环节
        Button dengyu = (Button)findViewById(R.id.dengyu);
        dengyu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                TextView ed1 = (TextView) findViewById(R.id.ed1);
                if (ed1.getText().toString().equals("") || ed1.getText().toString().equals(" ")) {
                    TextView tx = (TextView) findViewById(R.id.tx);
                    tx.setText("未输入算式");
                }
                else if(kuohao[0]==1){
                    TextView tx = (TextView)findViewById(R.id.tx);
                    tx.setText("前面有左括号，还未放入右括号");
                }
                else {
                    if (((int) (ed1.getText().toString() + "").charAt(0) > 47 && (int) (ed1.getText().toString() + "").charAt(0) < 58)||ed1.getText().toString().charAt(0)=='-') {
                        //如果前一位是数字（负数也是数字  因此第一位是负号也算）
                        M[a[0]] = Double.parseDouble(ed1.getText().toString() + "");
                    }
                    int p = -1;
                    int q = -1;
                    for (int i = 0; i < 10; i++) {     //先计算括号内
                        if (N[i] == '(') {
                            p = i;      //记录左括号位置
                        }
                        if (N[i] == ')') {
                            q = i;
                        }
                    }
                    if (p > -1) {   //如果存在括号
                        int T = 0;     //用T辅助判断有几个乘法
                        for (int i = p + 1; i < q + 1; i++) {
                            if (N[i] == 'X') {    //如果遇到了 乘法  先判断数字是否可用
                                int u = i + 1;
                                int o = i;
                                for (int j = i + 1; j < q + 1; j++) {
                                    if (M[j] != -1) {
                                        u = j;
                                        break;
                                    }
                                }
                                for (int j = i; j > p; j--) {
                                    if (M[j] != -1) {
                                        o = j;
                                        break;
                                    }
                                }
                                T++;


                                //这里因为double之间的运算会先转化成二进制值  因此会产生精度问题  所以改成BigDecimal方法来运算
                                M[o] = BigDecimal.valueOf(M[o]).multiply(BigDecimal.valueOf(M[u])).doubleValue();

                                if (T > 1) {
                                    M[o] = -1 * M[o];
                                }
                                M[u] = -1;   //将乘数标记为不可用
                                N[o] = 0;     //该运算符标记为不可用

                            }
                            if (N[i] == '÷') {    //如果遇到了 除法  先判断数字是否可用
                                int u = i + 1;
                                int o = i;
                                for (int j = i + 1; j < q + 1; j++) {
                                    if (M[j] != -1) {
                                        u = j;
                                        break;
                                    }
                                }
                                for (int j = i; j > p; j--) {
                                    if (M[j] != -1) {
                                        o = j;
                                        break;
                                    }
                                }
//                            M[o] = BigDecimal.valueOf(M[o]).divide(BigDecimal.valueOf(M[u])).doubleValue();  //这里之所以不用BigDecimal是因为10÷3这种运算除不尽 会导致程序崩溃 所以直接使用double的运算可以省略精度问题
                                M[o] = M[o] / M[u];
                                M[u] = -1;   //将除数标记为不可用
                                N[o] = 0;     //该运算符标记为不可用
                            }
                        }
                        for (int i = p + 1; i < q + 1; i++) {
                            if (N[i] == '+') {    //如果遇到了 加法  这里进行双向查找数  u向后查找 v向前查找
                                int u = i + 1;
                                int o = i;
                                for (int j = i + 1; j < q + 1; j++) {
                                    if (M[j] != -1) {
                                        u = j;
                                        break;
                                    }
                                }
                                for (int j = i; j > p; j--) {
                                    if (M[j] != -1) {
                                        o = j;
                                        break;
                                    }
                                }
                                M[o] = BigDecimal.valueOf(M[o]).add(BigDecimal.valueOf(M[u])).doubleValue();
                                M[u] = -1;   //将加数标记为不可用
                                N[i] = 0; //该运算符标记为不可用
                            }
                            if (N[i] == '-') {    //如果遇到了 减法  这里进行双向查找数  u向后查找 v向前查找
                                int u = i + 1;
                                int o = i;
                                for (int j = i + 1; j < q + 1; j++) {
                                    if (M[j] != -1) {
                                        u = j;
                                        break;
                                    }
                                }
                                for (int j = i; j > p; j--) {
                                    if (M[j] != -1) {
                                        o = j;
                                        break;
                                    }
                                }
                                M[o] = BigDecimal.valueOf(M[o]).subtract(BigDecimal.valueOf(M[u])).doubleValue();
                                M[u] = -1;   //将减数标记为不可用
                                N[i] = 0;     //该运算符标记为不可用
                            }
                        }
                    }     //这里是括号内的计算结束  括号外的运算方法和内部一样  只是界定范围不同
                    // 这里其实可以构造一个方法  输入字符串 输出结果  可以省略很大的代码量  我这里直接复制粘贴 将整体的运算方法
                    for (int i = 0; i < N.length; i++) {
                        if (N[i] == 'X') {    //如果遇到了 乘法  先判断数字是否可用
                            int u = i + 1;
                            int o = i;
                            for (int j = i + 1; j < N.length; j++) {
                                if (M[j] != -1) {
                                    u = j;
                                    break;
                                }
                            }
                            for (int j = i; j > -1; j--) {
                                if (M[j] != -1) {
                                    o = j;
                                    break;
                                }
                            }
                            M[o] = BigDecimal.valueOf(M[o]).multiply(BigDecimal.valueOf(M[u])).doubleValue();
                            M[u] = -1;   //将乘数标记为不可用
                            N[o] = 0;     //该运算符标记为不可用
                        }
                        if (N[i] == '÷' && M[i] != -1) {    //如果遇到了 除法  先判断数字是否可用
                            int u = i + 1;
                            int o = i;
                            for (int j = i + 1; j < N.length; j++) {
                                if (M[j] != -1) {
                                    u = j;
                                    break;
                                }
                            }
                            for (int j = i; j > -1; j--) {
                                if (M[j] != -1) {
                                    o = j;
                                    break;
                                }
                            }
//                        M[o] = BigDecimal.valueOf(M[o]).divide(BigDecimal.valueOf(M[u])).doubleValue();
                            M[o] = M[o] / M[u];
                            M[u] = -1;   //将除数标记为不可用
                            N[o] = 0;     //该运算符标记为不可用
                        }
                    }
                    for (int i = 0; i < N.length; i++) {
                        if (N[i] == '+') {    //如果遇到了 加法  这里进行双向查找数  u向后查找 v向前查找
                            int u = i + 1;
                            int o = i;
                            for (int j = i + 1; j < N.length; j++) {
                                if (M[j] != -1) {
                                    u = j;
                                    break;
                                }
                            }
                            for (int j = i; j > -1; j--) {
                                if (M[j] != -1) {
                                    o = j;
                                    break;
                                }
                            }
                            M[o] = BigDecimal.valueOf(M[o]).add(BigDecimal.valueOf(M[u])).doubleValue();
                            M[u] = -1;   //将加数标记为不可用
                            N[i] = 0; //该运算符标记为不可用
                        }
                        if (N[i] == '-') {    //如果遇到了 减法  这里进行双向查找数  u向后查找 v向前查找
                            int u = i + 1;
                            int o = i;
                            for (int j = i + 1; j < N.length; j++) {
                                if (M[j] != -1) {
                                    u = j;
                                    break;
                                }
                            }
                            for (int j = i; j > -1; j--) {
                                if (M[j] != -1) {
                                    o = j;
                                    break;
                                }
                            }
                            M[o] = BigDecimal.valueOf(M[o]).subtract(BigDecimal.valueOf(M[u])).doubleValue();
                            M[u] = -1;   //将减数标记为不可用
                            N[i] = 0;     //该运算符标记为不可用
                        }
                    }

                    //最后这里说一下  如果是以小括号开头的算是  那么他的M[0]始终都会是-1 因为从一开始就一直是-1
                    // 而且因为左括号的关系 第一位数字是出现在M[1]位置的  所以最终结果也是在M[1]   因此输出之前要判断是否要将M[1]放入M[0]
                    if(M[0]==-1){
                        M[0]=M[1];
                    }

                    ed1.setText(M[0] + "");
                    for (int i = 0; i < 10; i++) {     //考虑到用户可能会利用上一次运算的结果作为下一次的输入 因此提前将数的数组和运算符的数组清空 并将a和c设置为0，使得下一次输入数字和运算符从0位置开始
                        M[i] = -1;
                    }
                    for (int i = 0; i < 10; i++) {
                        N[i] = 0;
                    }
                    a[0] = 0;
                    c[0] = 0;


                }
            }
        });





            }
            //启动横屏
            public void startSecondActivity(View view){
                Intent intent = new Intent();
                intent.setClass(this,SecondActivity.class);
                //启动
                startActivity(intent);
            }
        public static boolean isNumeric(String str)        //这里设置一个方法用来判断是否是数字
         {
        for (int i = 0; i < str.length(); i++)
        {
            System.out.println(str.charAt(i));
            if (!Character.isDigit(str.charAt(i))&&str.charAt(i)!='.'&&str.charAt(i)!='-')
            {
                return false;
            }
        }return true;
         }
        }




